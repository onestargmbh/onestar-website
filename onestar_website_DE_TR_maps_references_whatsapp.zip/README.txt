# OneStar GmbH – Gratis Website (GitHub Pages)

## Inhalt
- `index.html` Startseite
- `impressum.html` Impressum (Vorlage)
- `datenschutz.html` Datenschutz (Vorlage)
- `styles.css` Design
- `logo.jpg` Logo

## Online stellen (ohne monatliche Kosten)
1) GitHub Konto erstellen: https://github.com
2) Neues Repository anlegen: **onestar-website** (öffentlich)
3) Diese Dateien hochladen (Drag&Drop im Repo möglich)
4) Im Repo: **Settings** → **Pages**
   - Source: **Deploy from a branch**
   - Branch: **main** / folder: **/(root)**
5) Nach dem Speichern bekommst du eine URL wie:
   `https://DEINNAME.github.io/onestar-website/`

## Optional: Eigene Domain (kostet meistens jährlich)
Wenn du später z.B. `onestar-gmbh.de` willst, kann man das mit GitHub Pages verbinden.


## Türkçe sayfalar
- index_tr.html
- impressum_tr.html
- datenschutz_tr.html
Sayfalar üst menüden DE/TR geçişi ile birbirine bağlıdır.
